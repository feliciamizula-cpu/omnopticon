using Argus.BuildingBlocks.EventBus;
using Argus.BuildingBlocks.Workers;
using Argus.Contracts.Assets;
using Argus.Contracts.Events;
using Argus.Contracts.Tasks;
using Argus.ServiceDefaults;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using System.Collections.Concurrent;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

builder.AddBasicServiceDefaults();

if (!string.IsNullOrWhiteSpace(builder.Configuration.GetConnectionString("argusdb")))
{
    builder.Services.AddDbContext<TaskDbContext>(options =>
        options.UseNpgsql(builder.Configuration.GetConnectionString("argusdb")));
    builder.Services.AddArgusEfCoreOutbox<TaskDbContext>();
    builder.Services.AddArgusInboxConsumer<TaskDbContext>();
    builder.Services.AddHealthChecks()
        .AddNpgSql(builder.Configuration.GetConnectionString("argusdb")!, name: "argusdb", tags: ["db", "sql", "postgres"]);
    builder.Services.AddScoped<ITaskStore, EfTaskStore>();
    builder.Services.AddHostedService<TaskMaintenanceService>();
}
else
{
    builder.Services.AddSingleton<ITaskStore, InMemoryTaskStore>();
}

builder.AddArgusIntegrationEvents(options => options.SourceService = "Argus.TaskService");
builder.Services.AddScoped<AssetPipelineConsumer>();
builder.Services.AddScoped<IIntegrationEventConsumer<AssetDiscovered>>(provider => provider.GetRequiredService<AssetPipelineConsumer>());
builder.Services.AddScoped<IIntegrationEventConsumer<AssetConfirmed>>(provider => provider.GetRequiredService<AssetPipelineConsumer>());
builder.Services.AddProblemDetails();

var app = builder.Build();

await app.InitializeTaskStoreAsync();
app.MapDefaultEndpoints();

app.MapGet("/tasks", (
    Guid? programId,
    ReconTaskState? state,
    string? capability,
    ITaskStore store,
    CancellationToken cancellationToken) =>
    store.QueryAsync(programId, state, capability, cancellationToken));

app.MapPost("/tasks", async (
    CreateReconTaskRequest request,
    ITaskStore store,
    IIntegrationEventPublisher events,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.TaskType) || string.IsNullOrWhiteSpace(request.WorkerCapability))
    {
        return Results.BadRequest("Task type and worker capability are required.");
    }

    var task = await store.CreateAsync(request, cancellationToken);
    await events.PublishAsync(
        new TaskRequested(task.TaskId, task.TaskType, task.ProgramId, task.InputAssetId),
        nameof(TaskRequested),
        "Argus.TaskService",
        cancellationToken: cancellationToken);

    return Results.Created($"/tasks/{task.TaskId}", task);
});

app.MapPost("/tasks/bulk/enqueue", async (
    BulkEnqueueRequest request,
    ITaskStore store,
    IIntegrationEventPublisher events,
    CancellationToken cancellationToken) =>
{
    if (request.AssetIds.Count == 0)
    {
        return Results.BadRequest("At least one asset ID is required.");
    }

    if (string.IsNullOrWhiteSpace(request.TaskType) || string.IsNullOrWhiteSpace(request.WorkerCapability))
    {
        return Results.BadRequest("Task type and worker capability are required.");
    }

    var createdTasks = new List<ReconTaskDto>();

    foreach (var assetId in request.AssetIds)
    {
        var createRequest = new CreateReconTaskRequest(
            TaskType: request.TaskType,
            ProgramId: request.ProgramId,
            ScopeId: request.ScopeId,
            InputAssetId: assetId,
            InputPayloadJson: null,
            WorkerCapability: request.WorkerCapability,
            RequiredAssetType: null,
            MaxAttempts: request.MaxAttempts,
            Priority: request.Priority,
            DedupeHash: null);

        var task = await store.CreateAsync(createRequest, cancellationToken);
        createdTasks.Add(task);
    }

    foreach (var task in createdTasks)
    {
        await events.PublishAsync(
            new TaskRequested(task.TaskId, task.TaskType, task.ProgramId, task.InputAssetId),
            nameof(TaskRequested),
            "Argus.TaskService",
            cancellationToken: cancellationToken);
    }

    var response = new BulkEnqueueResponse(createdTasks, createdTasks.Count, 0);
    return Results.Created("/tasks/bulk/enqueue", response);
});

app.MapGet("/tasks/{taskId:guid}", async (
    Guid taskId,
    ITaskStore store,
    CancellationToken cancellationToken) =>
{
    var task = await store.FindAsync(taskId, cancellationToken);
    return task is not null ? Results.Ok(task) : Results.NotFound();
});

app.MapPost("/tasks/lease", async (
    LeaseReconTaskRequest request,
    ITaskStore store,
    IIntegrationEventPublisher events,
    CancellationToken cancellationToken) =>
{
    var task = await store.LeaseAsync(request, cancellationToken);

    if (task is null)
    {
        return Results.NoContent();
    }

    await events.PublishAsync(
        new TaskLeased(task.TaskId, request.WorkerId, task.LeaseExpiresAt ?? DateTimeOffset.UtcNow),
        nameof(TaskLeased),
        "Argus.TaskService",
        cancellationToken: cancellationToken);

    return Results.Ok(task);
});

app.MapPost("/tasks/{taskId:guid}/start", async (
    Guid taskId,
    string workerId,
    ITaskStore store,
    IIntegrationEventPublisher events,
    CancellationToken cancellationToken) =>
{
    var task = await store.StartAsync(taskId, workerId, cancellationToken);

    if (task is null)
    {
        return Results.NotFound();
    }

    await events.PublishAsync(
        new TaskStarted(task.TaskId, workerId, task.StartedAt ?? DateTimeOffset.UtcNow),
        nameof(TaskStarted),
        "Argus.TaskService",
        cancellationToken: cancellationToken);

    return Results.Ok(task);
});

app.MapPost("/tasks/{taskId:guid}/progress", async (
    Guid taskId,
    UpdateReconTaskProgressRequest request,
    ITaskStore store,
    IIntegrationEventPublisher events,
    CancellationToken cancellationToken) =>
{
    var task = await store.ProgressAsync(taskId, request, cancellationToken);

    if (task is null)
    {
        return Results.NotFound();
    }

    await events.PublishAsync(
        new TaskProgressed(task.TaskId, task.ProgressPercent, task.ProgressMessage ?? string.Empty),
        nameof(TaskProgressed),
        "Argus.TaskService",
        cancellationToken: cancellationToken);

    return Results.Ok(task);
});

app.MapPost("/tasks/{taskId:guid}/complete", async (
    Guid taskId,
    CompleteReconTaskRequest request,
    ITaskStore store,
    IIntegrationEventPublisher events,
    CancellationToken cancellationToken) =>
{
    var task = await store.CompleteAsync(taskId, request, cancellationToken);

    if (task is null)
    {
        return Results.NotFound();
    }

    await events.PublishAsync(
        new TaskCompleted(task.TaskId, task.InputAssetId, task.OutputSummaryJson ?? "{}"),
        nameof(TaskCompleted),
        "Argus.TaskService",
        cancellationToken: cancellationToken);

    return Results.Ok(task);
});

app.MapPost("/tasks/{taskId:guid}/fail", async (
    Guid taskId,
    FailReconTaskRequest request,
    ITaskStore store,
    IIntegrationEventPublisher events,
    CancellationToken cancellationToken) =>
{
    var task = await store.FailAsync(taskId, request, cancellationToken);

    if (task is null)
    {
        return Results.NotFound();
    }

    await events.PublishAsync(
        new TaskFailed(task.TaskId, task.ErrorCode ?? "Unknown", task.ErrorMessage ?? string.Empty),
        nameof(TaskFailed),
        "Argus.TaskService",
        cancellationToken: cancellationToken);

    return Results.Ok(task);
});

app.MapPost("/tasks/{taskId:guid}/cancel", async (
    Guid taskId,
    CancelTaskRequest request,
    ITaskStore store,
    IIntegrationEventPublisher events,
    CancellationToken cancellationToken) =>
{
    var task = await store.CancelAsync(taskId, request.Reason, cancellationToken);

    if (task is null)
    {
        return Results.NotFound();
    }

    return Results.Ok(task);
});

app.MapPost("/tasks/{taskId:guid}/retry", async (
    Guid taskId,
    ITaskStore store,
    IIntegrationEventPublisher events,
    CancellationToken cancellationToken) =>
{
    var task = await store.RetryAsync(taskId, cancellationToken);

    if (task is null)
    {
        return Results.NotFound();
    }

    await events.PublishAsync(
        new TaskRequested(task.TaskId, task.TaskType, task.ProgramId, task.InputAssetId),
        nameof(TaskRequested),
        "Argus.TaskService",
        cancellationToken: cancellationToken);

    return Results.Ok(task);
});

app.MapPost("/tasks/{taskId:guid}/heartbeat", async (
    Guid taskId,
    string workerId,
    ITaskStore store,
    CancellationToken cancellationToken) =>
{
    var task = await store.HeartbeatAsync(taskId, workerId, cancellationToken);
    return task is not null ? Results.Ok(task) : Results.NotFound();
});

app.MapGet("/tasks/{taskId:guid}/history", async (
    Guid taskId,
    ITaskStore store,
    CancellationToken cancellationToken) =>
{
    var history = await store.GetHistoryAsync(taskId, cancellationToken);
    return Results.Ok(history);
});

app.MapGet("/tasks/dedupe/{dedupeHash}", async (
    string dedupeHash,
    ITaskStore store,
    CancellationToken cancellationToken) =>
{
    var task = await store.FindByDedupeAsync(dedupeHash, cancellationToken);
    return task is not null ? Results.Ok(task) : Results.NotFound();
});

app.MapGet("/tasks/retry-queue", async (
    Guid? programId,
    ReconTaskState? state,
    string? capability,
    int? take,
    TaskDbContext dbContext,
    CancellationToken cancellationToken) =>
{
    var query = dbContext.Tasks.AsNoTracking();

    if (state.HasValue)
    {
        query = query.Where(t => t.State == state.Value);
    }
    else
    {
        query = query.Where(t => t.State == ReconTaskState.RetryPending);
    }

    if (programId.HasValue)
    {
        query = query.Where(t => t.ProgramId == programId.Value);
    }

    if (!string.IsNullOrWhiteSpace(capability))
    {
        query = query.Where(t => t.WorkerCapability == capability);
    }

    var tasks = await query
        .OrderBy(t => t.Attempt)
        .ThenBy(t => t.Priority)
        .Take(Math.Clamp(take ?? 100, 1, 1000))
        .ToListAsync(cancellationToken);

    return Results.Ok(tasks.Select(t => t.ToDto()).ToArray());
});

app.MapPost("/tasks/retry-queue/dispatch", async (
    Guid? taskId,
    int? dispatchCount,
    TaskDbContext dbContext,
    IIntegrationEventPublisher events,
    ILogger<Program> logger,
    CancellationToken cancellationToken) =>
{
    var now = DateTimeOffset.UtcNow;
    int dispatched = 0;

    if (taskId.HasValue)
    {
        var task = await dbContext.Tasks.FindAsync([taskId.Value], cancellationToken);
        if (task is null || task.State != ReconTaskState.RetryPending)
        {
            return Results.NotFound();
        }

        task.State = ReconTaskState.Requested;
        dbContext.TaskHistory.Add(new TaskHistoryRecord
        {
            HistoryId = Guid.NewGuid(),
            TaskId = task.TaskId,
            State = ReconTaskState.RetryPending,
            Timestamp = now,
            Message = $"Manual dispatch (attempt {task.Attempt}/{task.MaxAttempts})"
        });

        await events.PublishAsync(
            new TaskRequested(task.TaskId, task.TaskType, task.ProgramId, task.InputAssetId),
            nameof(TaskRequested),
            "Argus.TaskService",
            cancellationToken: cancellationToken);

        await dbContext.SaveChangesAsync(cancellationToken);
        return Results.Ok(new { taskId, dispatched = 1 });
    }

    var count = Math.Clamp(dispatchCount ?? 50, 1, 500);
    var pending = await dbContext.Tasks
        .Where(t => t.State == ReconTaskState.RetryPending && t.Attempt < t.MaxAttempts)
        .OrderBy(t => t.Attempt)
        .Take(count)
        .ToListAsync(cancellationToken);

    foreach (var task in pending)
    {
        task.State = ReconTaskState.Requested;
        dbContext.TaskHistory.Add(new TaskHistoryRecord
        {
            HistoryId = Guid.NewGuid(),
            TaskId = task.TaskId,
            State = ReconTaskState.RetryPending,
            Timestamp = now,
            Message = $"Bulk dispatch (attempt {task.Attempt}/{task.MaxAttempts})"
        });

        await events.PublishAsync(
            new TaskRequested(task.TaskId, task.TaskType, task.ProgramId, task.InputAssetId),
            nameof(TaskRequested),
            "Argus.TaskService",
            cancellationToken: cancellationToken);

        dispatched++;
    }

    if (dispatched > 0)
    {
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    return Results.Ok(new { dispatched });
});

app.Run();

internal sealed class AssetPipelineConsumer(
    ITaskStore store,
    IIntegrationEventPublisher events,
    ILogger<AssetPipelineConsumer> logger)
    : IIntegrationEventConsumer<AssetDiscovered>, IIntegrationEventConsumer<AssetConfirmed>
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private static readonly HashSet<string> WebFetchTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        "Subdomain",
        "Url",
        "ApiEndpoint",
        "JavaScriptFile",
        "JsonDocument"
    };

    private static readonly HashSet<string> SpiderTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        "Subdomain",
        "Url",
        "HtmlPage"
    };

    private static readonly HashSet<string> RegexCandidateTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        "Url",
        "ApiEndpoint",
        "HtmlPage",
        "JsonDocument",
        "JavaScriptFile",
        "HttpResponse",
        "Observation"
    };

    public async Task HandleAsync(IntegrationEventEnvelope<AssetDiscovered> envelope, CancellationToken cancellationToken = default)
    {
        var asset = envelope.Payload;
        var assetType = asset.AssetType;

        if (string.Equals(assetType, "Domain", StringComparison.OrdinalIgnoreCase))
        {
            await EnqueueAsync(asset.ProgramId, asset.AssetId, "subdomain-enumeration", "SubfinderWorker",
                assetType, new { domain = asset.Value, assetType }, WorkerPriority.High, cancellationToken);

            await EnqueueAsync(asset.ProgramId, asset.AssetId, "subdomain-enumeration", "AmassWorker",
                assetType, new { domain = asset.Value, assetType }, WorkerPriority.High, cancellationToken);

            return;
        }

        if (WebFetchTypes.Contains(assetType))
        {
            var payload = CreateHttpPayload(assetType, asset.Value);
            await EnqueueAsync(asset.ProgramId, asset.AssetId, "http-probe", "HttpProbeWorker",
                assetType, payload, WorkerPriority.High, cancellationToken);
        }

        if (SpiderTypes.Contains(assetType))
        {
            var payload = CreateSpiderPayload(assetType, asset.Value);
            if (payload is not null)
            {
                await EnqueueAsync(asset.ProgramId, asset.AssetId, "spider", "HtmlDomSpiderWorker",
                    assetType, payload, WorkerPriority.Normal, cancellationToken);
            }
        }

        if (RegexCandidateTypes.Contains(assetType))
        {
            await EnqueueAsync(asset.ProgramId, asset.AssetId, "regex-scan-discovered", "RegexScannerWorker",
                assetType, new { assetId = asset.AssetId, assetType, value = asset.Value, eventStage = "discovered" },
                WorkerPriority.Normal, cancellationToken);
        }
    }

    public async Task HandleAsync(IntegrationEventEnvelope<AssetConfirmed> envelope, CancellationToken cancellationToken = default)
    {
        var asset = envelope.Payload;
        var assetType = asset.AssetType;

        if (RegexCandidateTypes.Contains(assetType))
        {
            await EnqueueAsync(asset.ProgramId, asset.AssetId, "regex-scan-confirmed", "RegexScannerWorker",
                assetType, new { assetId = asset.AssetId, assetType, value = asset.Value, eventStage = "confirmed" },
                WorkerPriority.High, cancellationToken);
        }

        if (string.Equals(assetType, "Url", StringComparison.OrdinalIgnoreCase)
            || string.Equals(assetType, "HtmlPage", StringComparison.OrdinalIgnoreCase))
        {
            await EnqueueAsync(asset.ProgramId, asset.AssetId, "spider", "HtmlDomSpiderWorker",
                assetType, CreateSpiderPayload(assetType, asset.Value) ?? new { url = asset.Value, assetType },
                WorkerPriority.Normal, cancellationToken);

            await EnqueueAsync(asset.ProgramId, asset.AssetId, "headless-spider", "HeadlessSpiderWorker",
                assetType, new { url = asset.Value, assetType },
                WorkerPriority.Normal, cancellationToken);

            await EnqueueAsync(asset.ProgramId, asset.AssetId, "fingerprint", "FingerprintWorker",
                assetType, new { url = asset.Value, assetType },
                WorkerPriority.Normal, cancellationToken);
        }

        if (string.Equals(assetType, "JavaScriptFile", StringComparison.OrdinalIgnoreCase))
        {
            await EnqueueAsync(asset.ProgramId, asset.AssetId, "js-extract", "JsExtractorWorker",
                assetType, new { url = asset.Value, assetType },
                WorkerPriority.Normal, cancellationToken);
        }
    }

    private async Task EnqueueAsync(
        Guid programId,
        Guid inputAssetId,
        string taskType,
        string workerCapability,
        string requiredAssetType,
        object payload,
        WorkerPriority priority,
        CancellationToken cancellationToken)
    {
        var request = new CreateReconTaskRequest(
            TaskType: taskType,
            ProgramId: programId,
            ScopeId: null,
            InputAssetId: inputAssetId,
            InputPayloadJson: JsonSerializer.Serialize(payload, JsonOptions),
            WorkerCapability: workerCapability,
            RequiredAssetType: requiredAssetType,
            MaxAttempts: 3,
            Priority: priority,
            DedupeHash: TaskDedupeHash.Compute(programId, null, taskType, inputAssetId, workerCapability));

        var task = await store.CreateAsync(request, cancellationToken);
        await events.PublishAsync(
            new TaskRequested(task.TaskId, task.TaskType, task.ProgramId, task.InputAssetId),
            nameof(TaskRequested),
            "Argus.TaskService",
            cancellationToken: cancellationToken);

        logger.LogInformation("Queued {TaskType} for asset {AssetId} using {WorkerCapability}", taskType, inputAssetId, workerCapability);
    }

    private static object CreateHttpPayload(string assetType, string value)
    {
        return string.Equals(assetType, "Subdomain", StringComparison.OrdinalIgnoreCase)
            ? new { host = value, assetType }
            : new { url = value.Split(' ', StringSplitOptions.RemoveEmptyEntries)[0], assetType };
    }

    private static object? CreateSpiderPayload(string assetType, string value)
    {
        if (string.Equals(assetType, "Subdomain", StringComparison.OrdinalIgnoreCase))
        {
            return new { url = $"https://{value.TrimEnd('/')}/", host = value, assetType };
        }

        var url = value.Split(' ', StringSplitOptions.RemoveEmptyEntries)[0];
        return Uri.TryCreate(url, UriKind.Absolute, out _) ? new { url, assetType } : null;
    }
}

internal interface ITaskStore
{
    Task<IReadOnlyCollection<ReconTaskDto>> QueryAsync(Guid? programId, ReconTaskState? state, string? capability, CancellationToken cancellationToken);
    Task<ReconTaskDto> CreateAsync(CreateReconTaskRequest request, CancellationToken cancellationToken);
    Task<ReconTaskDto?> FindAsync(Guid taskId, CancellationToken cancellationToken);
    Task<ReconTaskDto?> LeaseAsync(LeaseReconTaskRequest request, CancellationToken cancellationToken);
    Task<ReconTaskDto?> StartAsync(Guid taskId, string workerId, CancellationToken cancellationToken);
    Task<ReconTaskDto?> ProgressAsync(Guid taskId, UpdateReconTaskProgressRequest request, CancellationToken cancellationToken);
    Task<ReconTaskDto?> CompleteAsync(Guid taskId, CompleteReconTaskRequest request, CancellationToken cancellationToken);
    Task<ReconTaskDto?> FailAsync(Guid taskId, FailReconTaskRequest request, CancellationToken cancellationToken);
    Task<ReconTaskDto?> CancelAsync(Guid taskId, string reason, CancellationToken cancellationToken);
    Task<ReconTaskDto?> RetryAsync(Guid taskId, CancellationToken cancellationToken);
    Task<ReconTaskDto?> HeartbeatAsync(Guid taskId, string workerId, CancellationToken cancellationToken);
    Task<IReadOnlyCollection<TaskHistoryDto>> GetHistoryAsync(Guid taskId, CancellationToken cancellationToken);
    Task<ReconTaskDto?> FindByDedupeAsync(string dedupeHash, CancellationToken cancellationToken);
}

internal sealed class InMemoryTaskStore : ITaskStore
{
    private readonly ConcurrentDictionary<Guid, ReconTaskDto> _tasks = new();
    private readonly object _leaseLock = new();

    public Task<IReadOnlyCollection<ReconTaskDto>> QueryAsync(Guid? programId, ReconTaskState? state, string? capability, CancellationToken cancellationToken)
    {
        var tasks = _tasks.Values.AsEnumerable();

        if (programId is not null)
        {
            tasks = tasks.Where(task => task.ProgramId == programId);
        }

        if (state is not null)
        {
            tasks = tasks.Where(task => task.State == state);
        }

        if (!string.IsNullOrWhiteSpace(capability))
        {
            tasks = tasks.Where(task => string.Equals(task.WorkerCapability, capability, StringComparison.OrdinalIgnoreCase));
        }

        IReadOnlyCollection<ReconTaskDto> result = tasks
            .OrderByDescending(task => task.StartedAt ?? DateTimeOffset.MinValue)
            .ThenBy(task => task.TaskType, StringComparer.OrdinalIgnoreCase)
            .ToArray();

        return Task.FromResult(result);
    }

    public Task<ReconTaskDto> CreateAsync(CreateReconTaskRequest request, CancellationToken cancellationToken)
    {
        if (!string.IsNullOrWhiteSpace(request.DedupeHash))
        {
            var existing = _tasks.Values.FirstOrDefault(t => t.DedupeHash == request.DedupeHash);
            if (existing is not null)
            {
                return Task.FromResult(existing);
            }
        }

        var task = TaskMapping.CreateDto(request);
        _tasks[task.TaskId] = task;

        return Task.FromResult(task);
    }

    public Task<ReconTaskDto?> FindAsync(Guid taskId, CancellationToken cancellationToken)
    {
        _tasks.TryGetValue(taskId, out var task);
        return Task.FromResult(task);
    }

    public Task<ReconTaskDto?> LeaseAsync(LeaseReconTaskRequest request, CancellationToken cancellationToken)
    {
        lock (_leaseLock)
        {
            var now = DateTimeOffset.UtcNow;
            var subscribedAssetTypes = request.SubscribedAssetTypes is { Count: > 0 }
                ? request.SubscribedAssetTypes.ToHashSet(StringComparer.OrdinalIgnoreCase)
                : null;

            var candidate = _tasks.Values
                .Where(task => string.Equals(task.WorkerCapability, request.WorkerCapability, StringComparison.OrdinalIgnoreCase))
                .Where(task => task.RequiredAssetType is null || subscribedAssetTypes is null || subscribedAssetTypes.Contains(task.RequiredAssetType))
                .Where(task => task.State is ReconTaskState.Requested or ReconTaskState.Queued or ReconTaskState.RetryPending)
                .Where(task => task.Priority >= request.MinimumPriority)
                .OrderByDescending(task => task.Priority)
                .ThenBy(task => task.Attempt)
                .FirstOrDefault();

            if (candidate is null)
            {
                return Task.FromResult<ReconTaskDto?>(null);
            }

            var leased = candidate with
            {
                State = ReconTaskState.Leased,
                Attempt = candidate.Attempt + 1,
                LeaseOwner = request.WorkerId,
                LeaseExpiresAt = now.Add(TaskMapping.NormalizeLeaseDuration(request.LeaseDuration))
            };

            _tasks[leased.TaskId] = leased;
            return Task.FromResult<ReconTaskDto?>(leased);
        }
    }

    public Task<ReconTaskDto?> StartAsync(Guid taskId, string workerId, CancellationToken cancellationToken) =>
        TryUpdateAsync(taskId, task => task with
        {
            State = ReconTaskState.Running,
            LeaseOwner = workerId,
            StartedAt = DateTimeOffset.UtcNow,
            ProgressPercent = Math.Max(task.ProgressPercent, 1)
        });

    public Task<ReconTaskDto?> ProgressAsync(Guid taskId, UpdateReconTaskProgressRequest request, CancellationToken cancellationToken) =>
        TryUpdateAsync(taskId, task => task with
        {
            ProgressPercent = Math.Clamp(request.ProgressPercent, 0, 100),
            ProgressMessage = request.ProgressMessage,
            CheckpointJson = request.CheckpointJson ?? task.CheckpointJson
        });

    public Task<ReconTaskDto?> CompleteAsync(Guid taskId, CompleteReconTaskRequest request, CancellationToken cancellationToken) =>
        TryUpdateAsync(taskId, task => task with
        {
            State = request.PartiallySucceeded ? ReconTaskState.PartiallySucceeded : ReconTaskState.Succeeded,
            ProgressPercent = 100,
            CompletedAt = DateTimeOffset.UtcNow,
            OutputSummaryJson = request.OutputSummaryJson,
            LeaseExpiresAt = null
        });

    public Task<ReconTaskDto?> FailAsync(Guid taskId, FailReconTaskRequest request, CancellationToken cancellationToken) =>
        TryUpdateAsync(taskId, task =>
        {
            var canRetry = request.Retryable && task.Attempt < task.MaxAttempts;

            return task with
            {
                State = canRetry ? ReconTaskState.RetryPending : ReconTaskState.Failed,
                CompletedAt = canRetry ? null : DateTimeOffset.UtcNow,
                ErrorCode = request.ErrorCode,
                ErrorMessage = request.ErrorMessage,
                CheckpointJson = request.CheckpointJson ?? task.CheckpointJson,
                LeaseExpiresAt = null
            };
        });

    public Task<ReconTaskDto?> CancelAsync(Guid taskId, string reason, CancellationToken cancellationToken) =>
        TryUpdateAsync(taskId, task => task with
        {
            State = ReconTaskState.Cancelled,
            CompletedAt = DateTimeOffset.UtcNow,
            ErrorMessage = reason,
            LeaseExpiresAt = null
        });

    public Task<ReconTaskDto?> RetryAsync(Guid taskId, CancellationToken cancellationToken) =>
        TryUpdateAsync(taskId, task => task with
        {
            State = ReconTaskState.Requested,
            Attempt = 0,
            CompletedAt = null,
            ErrorCode = null,
            ErrorMessage = null,
            LeaseExpiresAt = null
        });

    public Task<ReconTaskDto?> HeartbeatAsync(Guid taskId, string workerId, CancellationToken cancellationToken) =>
        TryUpdateAsync(taskId, task =>
        {
            if (task.State != ReconTaskState.Running || task.LeaseOwner != workerId)
            {
                return task;
            }

            return task with
            {
                LeaseExpiresAt = DateTimeOffset.UtcNow.AddMinutes(5)
            };
        });

    public Task<IReadOnlyCollection<TaskHistoryDto>> GetHistoryAsync(Guid taskId, CancellationToken cancellationToken) =>
        Task.FromResult<IReadOnlyCollection<TaskHistoryDto>>([]);

    public Task<ReconTaskDto?> FindByDedupeAsync(string dedupeHash, CancellationToken cancellationToken) =>
        Task.FromResult(_tasks.Values.FirstOrDefault(t => t.DedupeHash == dedupeHash));

    private Task<ReconTaskDto?> TryUpdateAsync(Guid taskId, Func<ReconTaskDto, ReconTaskDto> update)
    {
        while (_tasks.TryGetValue(taskId, out var current))
        {
            var updated = update(current);

            if (_tasks.TryUpdate(taskId, updated, current))
            {
                return Task.FromResult<ReconTaskDto?>(updated);
            }
        }

        return Task.FromResult<ReconTaskDto?>(null);
    }
}

internal sealed class EfTaskStore(TaskDbContext dbContext) : ITaskStore
{
    public async Task<IReadOnlyCollection<ReconTaskDto>> QueryAsync(Guid? programId, ReconTaskState? state, string? capability, CancellationToken cancellationToken)
    {
        var tasks = dbContext.Tasks.AsNoTracking().AsQueryable();

        if (programId is not null)
        {
            tasks = tasks.Where(task => task.ProgramId == programId);
        }

        if (state is not null)
        {
            tasks = tasks.Where(task => task.State == state);
        }

        if (!string.IsNullOrWhiteSpace(capability))
        {
            tasks = tasks.Where(task => task.WorkerCapability == capability);
        }

        var records = await tasks
            .OrderByDescending(task => task.StartedAt ?? DateTimeOffset.MinValue)
            .ThenBy(task => task.TaskType)
            .ToArrayAsync(cancellationToken);

        return records.Select(task => task.ToDto()).ToArray();
    }

    public async Task<ReconTaskDto> CreateAsync(CreateReconTaskRequest request, CancellationToken cancellationToken)
    {
        if (!string.IsNullOrWhiteSpace(request.DedupeHash))
        {
            var existing = await dbContext.Tasks
                .AsNoTracking()
                .FirstOrDefaultAsync(t => t.DedupeHash == request.DedupeHash, cancellationToken);
            if (existing is not null)
            {
                return existing.ToDto();
            }
        }

        var record = TaskMapping.CreateRecord(request);
        dbContext.Tasks.Add(record);
        await dbContext.SaveChangesAsync(cancellationToken);

        return record.ToDto();
    }

    public async Task<ReconTaskDto?> FindAsync(Guid taskId, CancellationToken cancellationToken)
    {
        var task = await dbContext.Tasks.AsNoTracking().FirstOrDefaultAsync(task => task.TaskId == taskId, cancellationToken);
        return task?.ToDto();
    }

    public async Task<ReconTaskDto?> LeaseAsync(LeaseReconTaskRequest request, CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;
        var lockDuration = TaskMapping.NormalizeLeaseDuration(request.LeaseDuration);

        var parameters = new List<object>
        {
            ReconTaskState.Leased.ToString(),
            request.WorkerId,
            now.Add(lockDuration),
            request.WorkerCapability,
            (int)request.MinimumPriority
        };

        var assetTypeCondition = "";
        var subscribedAssetTypes = request.SubscribedAssetTypes;
        if (subscribedAssetTypes?.Count > 0)
        {
            var firstAssetTypeParameterIndex = parameters.Count;
            var capabilityFilter = string.Join(", ", subscribedAssetTypes.Select((_, i) => $"{{{firstAssetTypeParameterIndex + i}}}"));
            assetTypeCondition = @"
                AND (
                    ""RequiredAssetType"" IS NULL
                    OR ""RequiredAssetType"" IN (" + capabilityFilter + @")
                )";
            parameters.AddRange(subscribedAssetTypes);
        }

        var priorityCondition = $@"AND ""Priority"" >= {{4}}";

#pragma warning disable EF1002
        var rowsAffected = await dbContext.Database.ExecuteSqlRawAsync(
            $@"
            UPDATE recon_tasks
            SET ""State"" = {{0}},
                ""Attempt"" = ""Attempt"" + 1,
                ""LeaseOwner"" = {{1}},
                ""LeaseExpiresAt"" = {{2}}
            WHERE ""TaskId"" = (
                SELECT ""TaskId"" FROM recon_tasks
                WHERE ""WorkerCapability"" = {{3}}
                {assetTypeCondition}
                {priorityCondition}
                AND (""State"" = 'Requested' OR ""State"" = 'Queued' OR ""State"" = 'RetryPending')
                ORDER BY ""Priority"" DESC, ""Attempt"", ""TaskId""
                LIMIT 1
                FOR UPDATE SKIP LOCKED
            )
            ",
            parameters.ToArray());
#pragma warning restore EF1002

        if (rowsAffected == 0)
        {
            return null;
        }

        var task = await dbContext.Tasks
            .AsNoTracking()
            .FirstOrDefaultAsync(task => task.LeaseOwner == request.WorkerId && task.LeaseExpiresAt == now.Add(lockDuration), cancellationToken);

        return task?.ToDto();
    }

    public Task<ReconTaskDto?> StartAsync(Guid taskId, string workerId, CancellationToken cancellationToken) =>
        UpdateAsync(taskId, task =>
        {
            task.State = ReconTaskState.Running;
            task.LeaseOwner = workerId;
            task.StartedAt = DateTimeOffset.UtcNow;
            task.ProgressPercent = Math.Max(task.ProgressPercent, 1);
        }, cancellationToken);

    public Task<ReconTaskDto?> ProgressAsync(Guid taskId, UpdateReconTaskProgressRequest request, CancellationToken cancellationToken) =>
        UpdateAsync(taskId, task =>
        {
            task.ProgressPercent = Math.Clamp(request.ProgressPercent, 0, 100);
            task.ProgressMessage = request.ProgressMessage;
            task.CheckpointJson = request.CheckpointJson ?? task.CheckpointJson;
        }, cancellationToken);

    public Task<ReconTaskDto?> CompleteAsync(Guid taskId, CompleteReconTaskRequest request, CancellationToken cancellationToken) =>
        UpdateAsync(taskId, task =>
        {
            task.State = request.PartiallySucceeded ? ReconTaskState.PartiallySucceeded : ReconTaskState.Succeeded;
            task.ProgressPercent = 100;
            task.CompletedAt = DateTimeOffset.UtcNow;
            task.OutputSummaryJson = request.OutputSummaryJson;
            task.LeaseExpiresAt = null;
        }, cancellationToken);

    public Task<ReconTaskDto?> FailAsync(Guid taskId, FailReconTaskRequest request, CancellationToken cancellationToken) =>
        UpdateAsync(taskId, task =>
        {
            var canRetry = request.Retryable && task.Attempt < task.MaxAttempts;
            task.State = canRetry ? ReconTaskState.RetryPending : ReconTaskState.Failed;
            task.CompletedAt = canRetry ? null : DateTimeOffset.UtcNow;
            task.ErrorCode = request.ErrorCode;
            task.ErrorMessage = request.ErrorMessage;
            task.CheckpointJson = request.CheckpointJson ?? task.CheckpointJson;
            task.LeaseExpiresAt = null;
        }, cancellationToken);

    public Task<ReconTaskDto?> CancelAsync(Guid taskId, string reason, CancellationToken cancellationToken) =>
        UpdateAsync(taskId, task =>
        {
            task.State = ReconTaskState.Cancelled;
            task.CompletedAt = DateTimeOffset.UtcNow;
            task.ErrorMessage = reason;
            task.LeaseExpiresAt = null;
        }, cancellationToken);

    public Task<ReconTaskDto?> RetryAsync(Guid taskId, CancellationToken cancellationToken) =>
        UpdateAsync(taskId, task =>
        {
            task.State = ReconTaskState.Requested;
            task.Attempt = 0;
            task.CompletedAt = null;
            task.ErrorCode = null;
            task.ErrorMessage = null;
            task.LeaseExpiresAt = null;
        }, cancellationToken);

    public Task<ReconTaskDto?> HeartbeatAsync(Guid taskId, string workerId, CancellationToken cancellationToken) =>
        UpdateAsync(taskId, task =>
        {
            if (task.State != ReconTaskState.Running || task.LeaseOwner != workerId)
            {
                return;
            }

            task.LeaseExpiresAt = DateTimeOffset.UtcNow.AddMinutes(5);
        }, cancellationToken);

    public async Task<IReadOnlyCollection<TaskHistoryDto>> GetHistoryAsync(Guid taskId, CancellationToken cancellationToken)
    {
        return await dbContext.TaskHistory
            .AsNoTracking()
            .Where(h => h.TaskId == taskId)
            .OrderBy(h => h.Timestamp)
            .Select(h => new TaskHistoryDto(h.HistoryId, h.TaskId, h.State, h.Timestamp, h.WorkerId, h.Message, h.CheckpointSummary))
            .ToArrayAsync(cancellationToken);
    }

    public async Task<ReconTaskDto?> FindByDedupeAsync(string dedupeHash, CancellationToken cancellationToken)
    {
        var task = await dbContext.Tasks.AsNoTracking()
            .FirstOrDefaultAsync(t => t.DedupeHash == dedupeHash, cancellationToken);
        return task?.ToDto();
    }

    private async Task<ReconTaskDto?> UpdateAsync(Guid taskId, Action<TaskRecord> update, CancellationToken cancellationToken)
    {
        var task = await dbContext.Tasks.FirstOrDefaultAsync(task => task.TaskId == taskId, cancellationToken);

        if (task is null)
        {
            return null;
        }

        update(task);
        await dbContext.SaveChangesAsync(cancellationToken);

        return task.ToDto();
    }
}

internal sealed class TaskDbContext(DbContextOptions<TaskDbContext> options) : DbContext(options)
{
    public DbSet<TaskRecord> Tasks => Set<TaskRecord>();
    public DbSet<TaskHistoryRecord> TaskHistory => Set<TaskHistoryRecord>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var task = modelBuilder.Entity<TaskRecord>();
        task.ToTable("recon_tasks");
        task.HasKey(record => record.TaskId);
        task.HasIndex(record => new { record.ProgramId, record.State });
        task.HasIndex(record => new { record.WorkerCapability, record.State, record.Attempt });
        task.HasIndex(record => record.LeaseExpiresAt);
        task.HasIndex(record => record.DedupeHash);
        task.HasIndex(record => record.RequiredAssetType);
        task.Property(record => record.State).HasConversion<string>().HasMaxLength(64);
        task.Property(record => record.TaskType).HasMaxLength(128);
        task.Property(record => record.WorkerCapability).HasMaxLength(128);
        task.Property(record => record.LeaseOwner).HasMaxLength(256);
        task.Property(record => record.ErrorCode).HasMaxLength(128);
        task.Property(record => record.RequiredAssetType).HasMaxLength(64);
        task.Property(record => record.InputPayloadJson).HasColumnType("jsonb");
        task.Property(record => record.CheckpointJson).HasColumnType("jsonb");
        task.Property(record => record.OutputSummaryJson).HasColumnType("jsonb");

        var history = modelBuilder.Entity<TaskHistoryRecord>();
        history.ToTable("task_history");
        history.HasKey(record => record.HistoryId);
        history.HasIndex(record => record.TaskId);
        history.Property(record => record.State).HasConversion<string>().HasMaxLength(64);
        history.Property(record => record.Message).HasMaxLength(1024);

        modelBuilder.ConfigureArgusOutbox();
    }
}

internal sealed class TaskRecord
{
    public Guid TaskId { get; set; }
    public string TaskType { get; set; } = string.Empty;
    public Guid ProgramId { get; set; }
    public Guid? ScopeId { get; set; }
    public Guid? InputAssetId { get; set; }
    public string? InputPayloadJson { get; set; }
    public string WorkerCapability { get; set; } = string.Empty;
    public string? RequiredAssetType { get; set; }
    public ReconTaskState State { get; set; }
    public int Attempt { get; set; }
    public int MaxAttempts { get; set; }
    public string? LeaseOwner { get; set; }
    public DateTimeOffset? LeaseExpiresAt { get; set; }
    public DateTimeOffset? StartedAt { get; set; }
    public DateTimeOffset? CompletedAt { get; set; }
    public int ProgressPercent { get; set; }
    public string? ProgressMessage { get; set; }
    public string? CheckpointJson { get; set; }
    public string? OutputSummaryJson { get; set; }
    public string? ErrorCode { get; set; }
    public string? ErrorMessage { get; set; }
    public string? DedupeHash { get; set; }
    public string? ScopeSnapshotJson { get; set; }
    public WorkerPriority Priority { get; set; } = WorkerPriority.Normal;

    public ReconTaskDto ToDto() =>
        new(
            TaskId: TaskId,
            TaskType: TaskType,
            ProgramId: ProgramId,
            ScopeId: ScopeId,
            InputAssetId: InputAssetId,
            InputPayloadJson: InputPayloadJson,
            WorkerCapability: WorkerCapability,
            RequiredAssetType: RequiredAssetType,
            State: State,
            Attempt: Attempt,
            MaxAttempts: MaxAttempts,
            LeaseOwner: LeaseOwner,
            LeaseExpiresAt: LeaseExpiresAt,
            StartedAt: StartedAt,
            CompletedAt: CompletedAt,
            ProgressPercent: ProgressPercent,
            ProgressMessage: ProgressMessage,
            CheckpointJson: CheckpointJson,
            OutputSummaryJson: OutputSummaryJson,
            ErrorCode: ErrorCode,
            ErrorMessage: ErrorMessage,
            DedupeHash: DedupeHash,
            ScopeSnapshotJson: ScopeSnapshotJson,
            Priority: Priority);
}

internal sealed class TaskHistoryRecord
{
    public Guid HistoryId { get; set; }
    public Guid TaskId { get; set; }
    public ReconTaskState State { get; set; }
    public DateTimeOffset Timestamp { get; set; }
    public string? WorkerId { get; set; }
    public string? Message { get; set; }
    public string? CheckpointSummary { get; set; }
}

internal sealed class TaskMaintenanceService(IServiceScopeFactory scopeFactory, ILogger<TaskMaintenanceService> logger, IIntegrationEventPublisher events) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await RunMaintenanceAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error running task maintenance");
            }

            await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
        }
    }

    private async Task RunMaintenanceAsync(CancellationToken cancellationToken)
    {
        using var scope = scopeFactory.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<TaskDbContext>();
        var now = DateTimeOffset.UtcNow;

        var expiredLeases = await dbContext.Tasks
            .Where(t => t.State == ReconTaskState.Leased && t.LeaseExpiresAt < now)
            .ToListAsync(cancellationToken);

        foreach (var task in expiredLeases)
        {
            var canRetry = task.Attempt < task.MaxAttempts;
            var previousState = task.State;

            task.State = canRetry ? ReconTaskState.RetryPending : ReconTaskState.Expired;
            task.CompletedAt = canRetry ? null : now;

            dbContext.TaskHistory.Add(new TaskHistoryRecord
            {
                HistoryId = Guid.NewGuid(),
                TaskId = task.TaskId,
                State = previousState,
                Timestamp = now,
                Message = canRetry
                    ? $"Lease expired, requeued for retry (attempt {task.Attempt}/{task.MaxAttempts})"
                    : $"Lease expired, marked as expired after {task.Attempt} attempts"
            });

            logger.LogInformation("Task {TaskId} lease expired, state: {State}", task.TaskId, task.State);
        }

        var orphanedRunning = await dbContext.Tasks
            .Where(t => t.State == ReconTaskState.Running && t.LeaseExpiresAt < now)
            .ToListAsync(cancellationToken);

        foreach (var task in orphanedRunning)
        {
            task.State = ReconTaskState.HeartbeatLost;
            task.CompletedAt = now;

            dbContext.TaskHistory.Add(new TaskHistoryRecord
            {
                HistoryId = Guid.NewGuid(),
                TaskId = task.TaskId,
                State = ReconTaskState.Running,
                Timestamp = now,
                Message = "Heartbeat lost, marked as abandoned"
            });

            logger.LogWarning("Task {TaskId} heartbeat lost", task.TaskId);
        }

        if (expiredLeases.Count > 0 || orphanedRunning.Count > 0)
        {
            await dbContext.SaveChangesAsync(cancellationToken);
        }

        var retryPending = await dbContext.Tasks
            .Where(t => t.State == ReconTaskState.RetryPending && t.Attempt < t.MaxAttempts)
            .ToListAsync(cancellationToken);

        foreach (var task in retryPending)
        {
            task.State = ReconTaskState.Requested;

            dbContext.TaskHistory.Add(new TaskHistoryRecord
            {
                HistoryId = Guid.NewGuid(),
                TaskId = task.TaskId,
                State = ReconTaskState.RetryPending,
                Timestamp = now,
                Message = $"Retry dispatch (attempt {task.Attempt}/{task.MaxAttempts})"
            });

            await events.PublishAsync(
                new TaskRequested(task.TaskId, task.TaskType, task.ProgramId, task.InputAssetId),
                nameof(TaskRequested),
                "Argus.TaskService",
                cancellationToken: cancellationToken);

            logger.LogInformation("Task {TaskId} dispatched for retry (attempt {Attempt}/{MaxAttempts})", task.TaskId, task.Attempt, task.MaxAttempts);
        }

        if (retryPending.Count > 0)
        {
            await dbContext.SaveChangesAsync(cancellationToken);
        }
    }
}

internal static class TaskMapping
{
    public static ReconTaskDto CreateDto(CreateReconTaskRequest request)
    {
        var record = CreateRecord(request);
        return record.ToDto();
    }

    public static TaskRecord CreateRecord(CreateReconTaskRequest request) =>
        new()
        {
            TaskId = Guid.NewGuid(),
            TaskType = request.TaskType.Trim(),
            ProgramId = request.ProgramId,
            ScopeId = request.ScopeId,
            InputAssetId = request.InputAssetId,
            RequiredAssetType = request.RequiredAssetType,
            InputPayloadJson = request.InputPayloadJson,
            WorkerCapability = request.WorkerCapability.Trim(),
            State = ReconTaskState.Requested,
            Attempt = 0,
            MaxAttempts = Math.Max(1, request.MaxAttempts),
            ProgressPercent = 0,
            Priority = request.Priority,
            DedupeHash = request.DedupeHash
        };

    public static TimeSpan NormalizeLeaseDuration(TimeSpan leaseDuration) =>
        leaseDuration <= TimeSpan.Zero ? TimeSpan.FromMinutes(5) : leaseDuration;
}

internal static class TaskDedupeHash
{
    public static string Compute(Guid programId, Guid? scopeId, string taskType, Guid inputAssetId, string workerCapability)
    {
        var scopePart = scopeId?.ToString("N") ?? string.Empty;
        var input = $"{programId:N}:{scopePart}:{taskType}:{inputAssetId:N}:{workerCapability}";
        var hashBytes = System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(input));
        return Convert.ToHexString(hashBytes).ToLowerInvariant();
    }
}

internal static class TaskStoreInitialization
{
    public static async Task InitializeTaskStoreAsync(this WebApplication app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        var dbContext = scope.ServiceProvider.GetService<TaskDbContext>();

        if (dbContext is not null)
        {
            await dbContext.Database.EnsureCreatedAsync();
            await dbContext.Database.EnsureArgusOutboxCreatedAsync();
            await dbContext.Database.EnsureArgusInboxCreatedAsync();
        }
    }
}
